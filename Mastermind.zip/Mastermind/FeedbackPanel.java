import java.awt.*;
import javax.swing.*;

public class FeedbackPanel extends JPanel {
	
	//Fields
	private final static int CIRCLE_WIDTH = 20;
	private final static int CIRCLE_HEIGHT = 20;
	
	public JLabel[] circle;
	private char[] circleValue;
	

	public static ImageIcon circleRed;
	public static ImageIcon circleWhite;
	public static ImageIcon circleGrey;
	
	/**
	 * Constructor for the FeedbackPanel class
	 */
	
	public FeedbackPanel()
	{
		setLayout(new GridLayout(1, 4));
		Color sand = new Color(218, 221, 216);
		
		setBackground(sand);
		
		//declare image icons
		circleRed = new ImageIcon("Selection Button Red - Unpushed.png");
		circleWhite = new ImageIcon("Selection Button White - Unpushed.png");
		circleGrey = new ImageIcon("Selection Button White - Pushed.png");
		
		//resize image icons
		circleRed = resizeCircle(circleRed);
		circleWhite = resizeCircle(circleWhite);
		circleGrey = resizeCircle(circleGrey);
		
		circle = new JLabel[4];
		
		//declare circles
		for(int i = 0; i < circle.length; i++)
		{
			circle[i] = new JLabel(); 
			circle[i].setIcon(circleGrey);
			circle[i].setHorizontalAlignment(SwingConstants.CENTER);
			add(circle[i]);
		}
		
		circleValue = new char[4];
		
		circleValue[0] = 'w';
		circleValue[1] = 'w';
		circleValue[2] = 'w';
		circleValue[3] = 'w';
	}
	
	/**
	 * This method resizes an ImageIcon to the appropriate height and width of the buttons
	 * @param i - the ImageIcon that needs resized
	 * @return - the ImageIcon that has been resized
	 */
	
	public static ImageIcon resizeCircle(ImageIcon i)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(CIRCLE_WIDTH, CIRCLE_HEIGHT,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
	
	public void setButtonColor()
	{
		ImageIcon red = new ImageIcon("Selection Button Red - Pushed.png");
		
		circle[0].setIcon(red);
		
	}
	
	public char[] getButtonValues()
	{
		return circleValue;
	}
	
	public void setButtonValue(int i, char c)
	{
		if(c == 'r' || c == 'w')
			circleValue[i] = c;
	}
	
	
}
