import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class EndGameWindow extends JFrame{
	
	//Fields
	private final int WIDTH = 464;
	private final int HEIGHT = 325;
	
	//
	JLabel button;
	
	public EndGameWindow(char winOrLose, char color0, char color1, char color2, char color3)
	{
		
		//basic stuff
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//setLayout
		setLayout(new BorderLayout());
		
		//generate Header
		JLabel header = new JLabel();
		ImageIcon headerIcon = new ImageIcon();
		
		if(winOrLose == 'w')
		{
			headerIcon = new ImageIcon("You Win.png");
		}
		if(winOrLose == 'l')
		{
			headerIcon = new ImageIcon("You Lose.png");
		}
		headerIcon = resizeImage(headerIcon, 450, 100);
		header.setIcon(headerIcon);
		
		//generate stars
		JLabel[] stars = new JLabel[4];
		for(int i = 0; i < stars.length; i ++)
		{
			stars[i] = new JLabel();
		}
		stars[0].setIcon(setColor(color0));
		stars[1].setIcon(setColor(color1));
		stars[2].setIcon(setColor(color2));
		stars[3].setIcon(setColor(color3));
		
		JPanel starsPanel = new JPanel();
		starsPanel.setLayout(new GridLayout(1, 4));
		
		starsPanel.add(stars[0]);
		starsPanel.add(stars[1]);
		starsPanel.add(stars[2]);
		starsPanel.add(stars[3]);
		
		add(starsPanel, BorderLayout.CENTER);
		
		//generate button
		button = new JLabel();
		
		ImageIcon buttonLabel = new ImageIcon("Return - Unpushed.png");
		buttonLabel = resizeImage(buttonLabel, 450, 75);
		button.setIcon(buttonLabel);
		
		button.addMouseListener(new ReturnListener());
		
		add(button, BorderLayout.SOUTH);
		
		add(header, BorderLayout.NORTH);
		
		centerFrame();
		
		setVisible(true);
		
	}
	
	/**
	 * This method resizes an image
	 * @param i - the ImageIcon that will be resized
	 * @param w - the width of the new ImageIcon
	 * @param h - the height of the new ImageIcon
	 * @return the resized ImageIcon
	 */
	
	public static ImageIcon resizeImage(ImageIcon i, int w, int h)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
	
	private static ImageIcon setColor(char c)
	{
		
		ImageIcon defaultIcon = new ImageIcon("");
		
		ImageIcon redStar = new ImageIcon("Star Red.png");
		ImageIcon blueStar = new ImageIcon("Star Blue.png");
		ImageIcon whiteStar = new ImageIcon("Star White.png");
		ImageIcon orangeStar = new ImageIcon("Star Orange.png");
		ImageIcon greenStar = new ImageIcon("Star Green.png");
		ImageIcon purpleStar = new ImageIcon("Star Purple.png");
		
		redStar = resizeImage(redStar, 116, 116);
		blueStar = resizeImage(blueStar, 116, 116);
		whiteStar = resizeImage(whiteStar, 116, 116);
		orangeStar = resizeImage(orangeStar, 116, 116);
		greenStar = resizeImage(greenStar, 116, 116);
		purpleStar = resizeImage(purpleStar, 116, 116);
		
		if(c == 'r')
			return redStar;
		if(c == 'b')
			return blueStar;
		if(c == 'w')
			return whiteStar;
		if(c == 'o')
			return orangeStar;
		if(c == 'g')
			return greenStar;
		if(c == 'p')
			return purpleStar;
		
		return defaultIcon;
	}
	
	/**
	 * This method centers the frame on the screen.
	 */
	
	private void centerFrame()
	{
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - getWidth())/2);
		int y = (int) (((dimension.getHeight() - getHeight())/2));
		
		setLocation(x, y);
	}
	
	private class ReturnListener implements MouseListener
	{
		public void mouseClicked (MouseEvent e){}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonLabel = new ImageIcon("Return - Pushed.png");
			buttonLabel = resizeImage(buttonLabel, 450, 75);
			button.setIcon(buttonLabel);
		}

		public void mouseReleased(MouseEvent e) 
		{
			//goes to the game board
			new MainMenu();
			
			//hides the main menu
			setVisible(false);
			
			
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}
		
	}
}
