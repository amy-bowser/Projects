import java.awt.*;
import javax.swing.*;

public class FeedbackPanelContainer extends JPanel
{
	
	public FeedbackPanel[] feedBack;
	
	public FeedbackPanelContainer()
	{
		//set layout manager
		setLayout(new GridLayout(10, 1));
		
		//set color
		Color sand = new Color(218, 221, 216);
		setBackground(sand);
		
		//generate choice panels
		feedBack = new FeedbackPanel[10];
		for(int i = 9; i >= 0; i--)
		{
			feedBack[i] = new FeedbackPanel();
			add(feedBack[i]); 
		}
		
	}
}