import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * 
 * @author amy.bowser
 *
 */
public class ChoicePanel extends JPanel
{
	//Fields
	private final static int BUTTON_WIDTH = 40;
	private final static int BUTTON_HEIGHT = 40;

	
	public JLabel[] buttons;
	public char[] buttonValues;
	
	public ChoicePanel()
	{
		
		setLayout(new GridLayout(1,4));
		Color sand = new Color(218, 221, 216);
		
		setBackground(sand);
		
		//declare image icons
		ImageIcon greyDot = new ImageIcon("Selection Button White - Pushed.png");
		greyDot = resizeButton(greyDot);
		
		//declare buttons
		buttons = new JLabel[4];
		
		for(int i = 0; i < buttons.length; i ++)
		{
			buttons[i] = new JLabel();
			buttons[i].setIcon(greyDot);
			buttons[i].setHorizontalAlignment(SwingConstants.CENTER);
			add(buttons[i]);
		}
		
		buttonValues = new char[4];
		
		buttonValues[0] = 'w';
		buttonValues[1] = 'w';
		buttonValues[2] = 'w';
		buttonValues[3] = 'w';
	}
	
	
	/**
	 * This method resizes an ImageIcon to the appropriate height and width of the buttons
	 * @param i - the ImageIcon that needs resized
	 * @return - the ImageIcon that has been resized
	 */
	
	public static ImageIcon resizeButton(ImageIcon i)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(BUTTON_WIDTH, BUTTON_HEIGHT,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
	
	public void setButtonColor()
	{
		ImageIcon red = new ImageIcon("Selection Button Red - Pushed.png");
		
		buttons[0].setIcon(red);
		
		
	}
	
	public char[] getButtonValues()
	{
		return buttonValues;
	}
	
	public void setButtonValue(int i, char c)
	{
		if(c == 'r' || c == 'b' || c == 'w' || c == 'o' || c == 'g' || c == 'p')
			buttonValues[i] = c;
	}
	
	
	
}