import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Instructions extends JFrame
{
	//final ints for the size of the frame
	private final int WIDTH = 350;
	private final int HEIGHT = 490;
	
	//declaring components
	private JPanel mainPanel;
	private JLabel instructionsLabel;
	  
	/**
	 * Constructor for the instructions frame
	 */
	public Instructions()
	{
		//set size and title of the window
		setSize(WIDTH, HEIGHT);
		setTitle("Mastermind Instructions");
		
		//create mainPanel and set Color
		mainPanel = new JPanel();
		mainPanel.setBackground(Color.WHITE);
		
		//declare and resize image icon
		ImageIcon instructions = new ImageIcon("Instructions Panel.png");
		instructions = resizeImage(instructions, 350, 466);
		
		//declare instructionsLabel and add iamge icon
		instructionsLabel = new JLabel();
		instructionsLabel.setIcon(instructions);
		
		//add instructionsLabel to the mainPanel
		mainPanel.add(instructionsLabel);
		
		//add mainPanel to the JFrame
		add(mainPanel);
		
		//set the window to visible
		setVisible(true);
	}
	
	/**
	 * This method centers the frame on the screen.
	 */
	
	private void centerFrame()
	{
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - getWidth())/2);
		int y = (int) (((dimension.getHeight() - getHeight())/2));
		
		setLocation(x, y);
	}
	
	/**
	 * This method resizes an image
	 * @param i - the ImageIcon that will be resized
	 * @param w - the width of the new ImageIcon
	 * @param h - the height of the new ImageIcon
	 * @return the resized ImageIcon
	 */
	
	public static ImageIcon resizeImage(ImageIcon i, int w, int h)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
}