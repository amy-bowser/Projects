import java.awt.*;
import javax.swing.*;

public class ChoicePanelContainer extends JPanel
{
	
	public ChoicePanel[] choicePanels;
	public int level;
	
	public ChoicePanelContainer()
	{
		//set layout manager
		setLayout(new GridLayout(10, 1));
		
		//set color
		Color sand = new Color(218, 221, 216);
		setBackground(sand);
		
		//declare level
		level = 0;
		
		//generate choice panels
		choicePanels = new ChoicePanel[10];
		for(int i = 9; i >= 0; i--)
		{
			choicePanels[i] = new ChoicePanel();
			add(choicePanels[i]);
		}
		
		setToWhite();
	}
	
	/**
	 * This method resizes an ImageIcon to the appropriate height and width of the buttons
	 * @param i - the ImageIcon that needs resized
	 * @return - the ImageIcon that has been resized
	 */
	
	public static ImageIcon resizeButton(ImageIcon i)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(40, 40,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}

	public void setToWhite()
	{
		ImageIcon whiteDot = new ImageIcon("Selection Button White - Unpushed.png");
		whiteDot = resizeButton(whiteDot);
		
		choicePanels[level].buttons[0].setIcon(whiteDot);
		choicePanels[level].buttons[1].setIcon(whiteDot);
		choicePanels[level].buttons[2].setIcon(whiteDot);
		choicePanels[level].buttons[3].setIcon(whiteDot);
	}
	
	/**
	 * This method increases the level
	 */
	
	public void increaseLevel()
	{
		if (level < 9)
		{
			level++;
			setToWhite();
		}
	}
	
	/**
	 * This method gets the level
	 * @return 
	 */
	
	public int getLevel()
	{
		return level;
	}
}