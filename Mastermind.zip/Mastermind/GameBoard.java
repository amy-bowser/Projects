import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
import java.util.Random;

/**
 * 
 * @author amy.bowser
 *
 */
public class GameBoard extends JFrame
{
	//final ints for frame size
	private final int WIDTH = 450;
	private final int HEIGHT = 600;
	
	//declaring panels and labels
	private JPanel mainPanel, titlePanel, eastPanel, centerPanel, centerPanelTop, centerPanelBottom;
	private JLabel titleLabel, submitLabel;
	
	//creating a new class object
	public ColorSelectionPanel[] colorSelectionPanel;
	public ChoicePanel[] choicePanel;
	private ChoicePanelContainer cpContainer;
	private FeedbackPanelContainer fbContainer;
	private ColorSelectionPanelContainer cspContainer;
	
	//declaring char arrays for the patterns
	private char[] answerKey;
	private char[] guessKey;
	
	//setting the feedback dots to zero
	private int redDot = 0;
	private int whiteDot = 0;
	private int counter = 0;
	
	//Boolean arrays for activating the similarities
	private boolean[] guessKeyActivation;
	private boolean[] answerKeyActivation;
	   
	/**
	 * Constructor for the gameboard
	 */
	public GameBoard()
	{
		//sets the size and title of the gameboard
		setSize(WIDTH, HEIGHT);
		setTitle("Mastermind Game");
		
		//closes the JFRAME on with the X button
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//generates a random pattern
		answerKey = generateAnswerKey();
		
		//creating a main panel
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		
		//custom color and setting it to the main panel
		Color sand = new Color(218, 221, 216);
		mainPanel.setBackground(sand);
		setBackground(sand);
		
		//answerKey = generateAnswerKey();
		
		centerFrame();
		buildTitlePanel();
		buildEastPanel();
		buildCenterPanel();
		
		
		
		add(mainPanel);
		
		setVisible(true);
	}
	
	/**
	 * This method centers the frame on the screen.
	 */
	
	private void centerFrame()
	{
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - getWidth())/2);
		int y = (int) (((dimension.getHeight() - getHeight())/2));
		
		setLocation(x, y);
	}
	
	private char[] generateAnswerKey()
	{
		Random generator = new Random();
		char[] key = new char[4];
		int j;
		
		
	
		for(int i = 0; i < 4; i ++)
		{
			j = generator.nextInt(6);

			if(j == 0)
				key[i] = 'r';
			if(j == 1)
				key[i] = 'b';
			if(j == 2)
				key[i] = 'w';
			if(j == 3)
				key[i] = 'o';
			if(j == 4)
				key[i] = 'g';
			if(j == 5)
				key[i] = 'p';
		}
		return key;
	}
	
	/**
	 * Build titles panel
	 */
	
	public void buildTitlePanel()
	{
		titlePanel = new JPanel();
		titleLabel = new JLabel();
		titlePanel.setLayout(new GridLayout(1,1));
		
		ImageIcon gbTitle = new ImageIcon("Header.png");
		gbTitle = resizeImage(gbTitle, 450, 100);
		
		Color sand = new Color(218, 221, 216);
		
		titlePanel.setBackground(sand);
		
		titleLabel.setIcon(gbTitle);
		
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		titlePanel.add(titleLabel);
		
		mainPanel.add(titlePanel, BorderLayout.NORTH);
		
	}
	
	/**
	 * 
	 */
	
	public void buildEastPanel()
	{
		//declare panels
		eastPanel = new JPanel();
		
		//generate sand
		Color sand = new Color(218, 221, 216);
		
		//set layouts
		eastPanel.setLayout(new BorderLayout());
		
		fbContainer = new FeedbackPanelContainer();
		
		eastPanel.add(fbContainer, BorderLayout.CENTER);
		
		//create submit Label
		submitLabel = new JLabel();
		ImageIcon submit = new ImageIcon("Submit - Unpushed.png");
		submit = resizeImage(submit, 100, 50);
		submitLabel.setIcon(submit);
		submitLabel.setPreferredSize(new Dimension(80, 90));
		
		submitLabel.addMouseListener(new SubmitListener());
		
		//colors
		eastPanel.setBackground(sand);
		
		//setSize
		eastPanel.setPreferredSize(new Dimension(100, 500));
		
		eastPanel.add(submitLabel, BorderLayout.SOUTH);

		mainPanel.add(eastPanel, BorderLayout.EAST);
	}
	
	/**
	 * This method builds the center panel
	 */
	
	public void buildCenterPanel()
	{
		//declare panels
		centerPanel = new JPanel();
		centerPanelTop = new JPanel();
		centerPanelBottom = new JPanel();
		
		//set layouts
		centerPanel.setLayout(new BorderLayout());
		centerPanelTop.setLayout(new GridLayout(10,1));
		centerPanelBottom.setLayout(new GridLayout(1, 4));
		
		Color sand = new Color(218, 221, 216);
		centerPanel.setBackground(sand);
		centerPanelTop.setBackground(sand);
		centerPanelBottom.setBackground(sand);
		
		
		//generate cpContainer
		cpContainer = new ChoicePanelContainer();
		centerPanel.add(cpContainer, BorderLayout.CENTER);
		
		//generate cspContainer
		cspContainer = new ColorSelectionPanelContainer(cpContainer);
		centerPanel.add(cspContainer, BorderLayout.SOUTH);
		
		mainPanel.add(centerPanel, BorderLayout.CENTER);
		
		
	}
	
	/**
	 * 
	 * @author amy.bowser
	 *
	 */
	
	private class SubmitListener implements MouseListener
	{
		public void mouseClicked (MouseEvent e){}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon pressedSub = new ImageIcon("Submit - Pushed.png");
			pressedSub = resizeImage(pressedSub, 100, 50);
			submitLabel.setIcon(pressedSub);
		}

		public void mouseReleased(MouseEvent e) 
		{
			ImageIcon submit = new ImageIcon("Submit - Unpushed.png");
			submit = resizeImage(submit, 100, 50);
			submitLabel.setIcon(submit);
			
			guessKey = cpContainer.choicePanels[cpContainer.level].getButtonValues();
		
			
			guessKeyActivation = new boolean[4];
			guessKeyActivation[0] = true;
			guessKeyActivation[1] = true;
			guessKeyActivation[2] = true;
			guessKeyActivation[3] = true;
			
			answerKeyActivation = new boolean[4];
			answerKeyActivation[0] = true;
			answerKeyActivation[1] = true;
			answerKeyActivation[2] = true;
			answerKeyActivation[3] = true;
			
			if(guessKey[0] == answerKey[0])
			{
				redDot++;
				guessKeyActivation[0] = false;
				answerKeyActivation[0] = false;
			}
			if(guessKey[1] == answerKey[1])
			{
				redDot++;
				guessKeyActivation[1] = false;
				answerKeyActivation[1] = false;
			}
			if(guessKey[2] == answerKey[2])
			{
				redDot++;
				guessKeyActivation[2] = false;
				answerKeyActivation[2] = false;
			}
			if(guessKey[3] == answerKey[3])
			{
				redDot++;
				guessKeyActivation[3] = false;
				answerKeyActivation[3] = false;
			}
			
			
			if((guessKey[0] == answerKey[1]) && guessKeyActivation[0] == true && answerKeyActivation[1] == true)
			{
				whiteDot++;
				guessKeyActivation[0] = false;
				answerKeyActivation[1] = false;
			}
			if((guessKey[0] == answerKey[2]) && guessKeyActivation[0] == true && answerKeyActivation[2] == true)
			{
				whiteDot++;
				guessKeyActivation[0] = false;
				answerKeyActivation[2] = false;
			}
			if((guessKey[0] == answerKey[3]) && guessKeyActivation[0] == true && answerKeyActivation[3] == true)
			{
				whiteDot++;
				guessKeyActivation[0] = false;
				answerKeyActivation[3] = false;
			}
			if((guessKey[1] == answerKey[0]) && guessKeyActivation[1] == true && answerKeyActivation[0] == true)
			{
				whiteDot++;
				guessKeyActivation[1] = false;
				answerKeyActivation[0] = false;
			}
			if((guessKey[1] == answerKey[2]) && guessKeyActivation[1] == true && answerKeyActivation[2] == true)
			{
				whiteDot++;
				guessKeyActivation[1] = false;
				answerKeyActivation[2] = false;
			}
			if((guessKey[1] == answerKey[3]) && guessKeyActivation[1] == true && answerKeyActivation[3] == true)
			{
				whiteDot++;
				guessKeyActivation[1] = false;
				answerKeyActivation[3] = false;
			}
			if((guessKey[2] == answerKey[0]) && guessKeyActivation[2] == true && answerKeyActivation[0] == true)
			{
				whiteDot++;
				guessKeyActivation[2] = false;
				answerKeyActivation[0] = false;
			}
			if((guessKey[2] == answerKey[1]) && guessKeyActivation[2] == true && answerKeyActivation[1] == true)
			{
				whiteDot++;
				guessKeyActivation[2] = false;
				answerKeyActivation[1] = false;
			}
			if((guessKey[2] == answerKey[3]) && guessKeyActivation[2] == true && answerKeyActivation[3] == true)
			{
				whiteDot++;
				guessKeyActivation[2] = false;
				answerKeyActivation[3] = false;
			}
			if((guessKey[3] == answerKey[0]) && guessKeyActivation[3] == true && answerKeyActivation[0] == true)
			{
				whiteDot++;
				guessKeyActivation[3] = false;
				answerKeyActivation[0] = false;
			}
			if((guessKey[3] == answerKey[1]) && guessKeyActivation[3] == true && answerKeyActivation[1] == true)
			{
				whiteDot++;
				guessKeyActivation[3] = false;
				answerKeyActivation[1] = false;
			}
			if((guessKey[3] == answerKey[2]) && guessKeyActivation[3] == true && answerKeyActivation[2] == true)
			{
				whiteDot++;
				guessKeyActivation[3] = false;
				answerKeyActivation[2] = false;
			}
			
			System.out.println(counter);
			
			if(redDot == 1)
			{
				fbContainer.feedBack[cpContainer.level].circle[0].setIcon(FeedbackPanel.circleRed);
			}
				
			if(redDot == 2)
			{
				fbContainer.feedBack[cpContainer.level].circle[0].setIcon(FeedbackPanel.circleRed);
				fbContainer.feedBack[cpContainer.level].circle[1].setIcon(FeedbackPanel.circleRed);
			}
			
			if(redDot == 3)
			{
				fbContainer.feedBack[cpContainer.level].circle[0].setIcon(FeedbackPanel.circleRed);
				fbContainer.feedBack[cpContainer.level].circle[1].setIcon(FeedbackPanel.circleRed);
				fbContainer.feedBack[cpContainer.level].circle[2].setIcon(FeedbackPanel.circleRed);
			}
			
			if(redDot == 4)
			{
				new EndGameWindow('w', answerKey[0], answerKey[1], answerKey[2], answerKey[3]);
				answerKey = generateAnswerKey();
				setVisible(false);
			}
			

			if(whiteDot == 1)
			{
				fbContainer.feedBack[cpContainer.level].circle[redDot].setIcon(FeedbackPanel.circleWhite);
			}
			if(whiteDot == 2)
			{
				fbContainer.feedBack[cpContainer.level].circle[redDot].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 1].setIcon(FeedbackPanel.circleWhite);
			}
			if(whiteDot == 3)
			{
				fbContainer.feedBack[cpContainer.level].circle[redDot].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 1].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 2].setIcon(FeedbackPanel.circleWhite);
			}
			if(whiteDot == 4)
			{
				fbContainer.feedBack[cpContainer.level].circle[redDot].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 1].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 2].setIcon(FeedbackPanel.circleWhite);
				fbContainer.feedBack[cpContainer.level].circle[redDot + 3].setIcon(FeedbackPanel.circleWhite);
			}
			
			
			
			
			counter++;
			cpContainer.increaseLevel();
			
			
			if(counter == 10)
			{
				new EndGameWindow('l', answerKey[0], answerKey[1], answerKey[2], answerKey[3]);
				answerKey = generateAnswerKey();
				setVisible(false);
				
			}
			

			redDot = 0;
			whiteDot = 0;
			
			guessKeyActivation = new boolean[4];
			guessKeyActivation[0] = true;
			guessKeyActivation[1] = true;
			guessKeyActivation[2] = true;
			guessKeyActivation[3] = true;
			
			answerKeyActivation = new boolean[4];
			answerKeyActivation[0] = true;
			answerKeyActivation[1] = true;
			answerKeyActivation[2] = true;
			answerKeyActivation[3] = true;
			
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}
		
	}

	/**
	 * This method resizes an image
	 * @param i - the ImageIcon that will be resized
	 * @param w - the width of the new ImageIcon
	 * @param h - the height of the new ImageIcon
	 * @return the resized ImageIcon
	 */
	
	public static ImageIcon resizeImage(ImageIcon i, int w, int h)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
	
}
