import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

/**
 * 
 * Main method class for the main menu.
 *
 */
public class MainMenu extends JFrame
{
	//final ints for the size of the frame
	private final int WIDTH = 465;
	private final int HEIGHT = 240;
	
	//Declaring components
	private JPanel mainPanel, titlePanel, buttonPanel, playButtonPanel, instructionsButtonPanel;
	private JLabel playButtonLabel, instructionsButtonLabel;
	private JLabel titleLabel;
	
	/**
	 * This is the constructor for the 
	 * mastermind frame. This is where all 
	 * of the methods are called.
	 */
	
	public MainMenu()
	{
		//set set and title
		setSize(WIDTH, HEIGHT);
		setTitle("Mastermind Main Menu");
		
		//create color sand
		Color sand = new Color(218, 221, 216);
		
		//closes the JFRAME on with the X button
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//declare mainPanel and its properties
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(sand);
		
		//calling methods
		centerFrame();
		buildTitlePanel();
		buildButtonPanel();
		
		//add mainPanel to the JFrame
		add(mainPanel);
		
		//set the window to visible
		setVisible(true);
	}
	
	/**
	 * This method centers the frame on the screen.
	 */
	
	private void centerFrame()
	{
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - getWidth())/2);
		int y = (int) (((dimension.getHeight() - getHeight())/2));
		
		setLocation(x, y);
	}
	
	/**
	 * This builds the north panel
	 * with the title. This method
	 * requires an image as the title.
	 */
	
	private void buildTitlePanel()
	{
		//declare panel and label
		titlePanel = new JPanel();
		titleLabel = new JLabel();
		
		//declare and resize header imageIcon
		ImageIcon mastermindTitle = new ImageIcon("Header.png");
		mastermindTitle = resizeImage(mastermindTitle, 450, 100);
		
		//add icon to label
		titleLabel.setIcon(mastermindTitle);
		
		//add label to panel
		titlePanel.add(titleLabel);
		
		//create color sand
		Color sand = new Color(218, 221, 216);
		
		//set background of panel to sand
		titlePanel.setBackground(sand);
		
		//add to mainPanel
		mainPanel.add(titlePanel, BorderLayout.NORTH);
	}
	
	/**
	 * This method build the center
	 * button panel. This includes the
	 * play button and the instructions 
	 * button.
	 */
	
	private void buildButtonPanel()
	{
		//declare panel and its layout manager
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1, 2));
		
		//declare panel and label for play button
		playButtonPanel = new JPanel();
		playButtonLabel = new JLabel();
		
		//set Color of panel
		Color sand = new Color(218, 221, 216);
		playButtonPanel.setBackground(sand);
		
		//declare and resize play button image icon
		ImageIcon playButton = new ImageIcon("Play - Unpushed.png");
		playButton = resizeImage(playButton, 225, 75);
		
		//add icon to play button label
		playButtonLabel.setIcon(playButton);
		
		//add label to panel
		playButtonPanel.add(playButtonLabel);
		
		//calls the listener class for the play button
		playButtonLabel.addMouseListener(new PlayButtonListener());
		
		//declare panel and label for instructions button
		instructionsButtonPanel = new JPanel();
		instructionsButtonLabel = new JLabel();
		
		//declare and resize instructions button image icon
		ImageIcon instructionsButton = new ImageIcon("Instructions - Unpushed.png");
		instructionsButton = resizeImage(instructionsButton, 225, 75);
		
		//add icon to instructions button label
		instructionsButtonLabel.setIcon(instructionsButton);
		
		//add label to panel
		instructionsButtonPanel.add(instructionsButtonLabel);
		
		//set color of instructions panel
		instructionsButtonPanel.setBackground(sand);
		
		//calls the listener class to show the instructions
		instructionsButtonLabel.addMouseListener(new DirectionButtonListener());
		
		//add button panels
		buttonPanel.add(playButtonPanel);
		buttonPanel.add(instructionsButtonPanel);
		
		//add to main panel
		mainPanel.add(buttonPanel, BorderLayout.CENTER);
		
	}
	
	/**
	 * Listener for the instructions
	 * button.
	 */
	
	private class DirectionButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0){}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon pressedInstructButton = new ImageIcon("Instructions - Pushed.png");
			pressedInstructButton = resizeImage(pressedInstructButton, 225, 75);
			instructionsButtonLabel.setIcon(pressedInstructButton);
		}

		public void mouseReleased(MouseEvent e) 
		{
			ImageIcon instructionsButton = new ImageIcon("Instructions - Unpushed.png");
			instructionsButton = resizeImage(instructionsButton, 225, 75);
			instructionsButtonLabel.setIcon(instructionsButton);
			new Instructions();
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * This class is the listener for the 
	 * play button. It runs the game board
	 * when it is clicked.
	 */
	
	private class PlayButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent e){}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon pressedPlayButton = new ImageIcon("Play - Pushed.png");
			pressedPlayButton = resizeImage(pressedPlayButton, 225, 75);
			
			playButtonLabel.setIcon(pressedPlayButton);
		}

		public void mouseReleased(MouseEvent e) 
		{
			//goes to the game board
			new GameBoard();
			
			//hides the main menu
			setVisible(false);
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}
		
	}

	/**
	 * This method resizes an image
	 * @param i - the ImageIcon that will be resized
	 * @param w - the width of the new ImageIcon
	 * @param h - the height of the new ImageIcon
	 * @return the resized ImageIcon
	 */
	
	public static ImageIcon resizeImage(ImageIcon i, int w, int h)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
}

