import java.awt.*;
import javax.swing.*;

public class ColorSelectionPanelContainer extends JPanel
{
	
	ColorSelectionPanel[] colorSelectionPanels;
	
	public ColorSelectionPanelContainer(ChoicePanelContainer cpContainer)
	{
		//set layout manager
		setLayout(new GridLayout(1, 4));
		
		//set color
		Color sand = new Color(218, 221, 216);
		setBackground(sand);
		
		//generate color selection panels
		colorSelectionPanels = new ColorSelectionPanel[4];
		for(int i = 0; i < colorSelectionPanels.length; i++)
		{
			colorSelectionPanels[i] = new ColorSelectionPanel(cpContainer, i);
			add(colorSelectionPanels[i]);
		}
		
	}
}