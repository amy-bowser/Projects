/**
 * Jack Pellegrini && Amy Bowser
 * Period 4
 * June 1, 2017
 * This is the main method of the Mastermind program.
 */
public class Start 
{
	public static void main (String [] args)
	{
		MainMenu start = new MainMenu();
	}
}
