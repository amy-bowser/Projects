import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class ColorSelectionPanel extends JPanel 
{

	//Fields
	
	private final static int BUTTON_WIDTH = 30;
	private final static int BUTTON_HEIGHT = 30;
	
	//private JLabelbuttons;
	private JLabel button1;
	private JLabel button2;
	private JLabel button3;
	private JLabel button4;
	private JLabel button5;
	private JLabel button6;
	
	public ChoicePanelContainer cpContainer;	
	private int index;
	
	public ColorSelectionPanel(ChoicePanelContainer cp, int i)
	{
		cpContainer = cp;
		index = i;
		
		//declare labels and image icons
		setLayout(new GridLayout(3,2));
		Color sand = new Color(218, 221, 216);
		
		setBackground(sand);
		
		//setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		
		//declare image icons
		ImageIcon buttonRedUnpushed = new ImageIcon("Selection Button Red - Unpushed.png");
		ImageIcon buttonBlueUnpushed = new ImageIcon("Selection Button Blue - Unpushed.png");
		ImageIcon buttonWhiteUnpushed = new ImageIcon("Selection Button White - Unpushed.png");
		ImageIcon buttonOrangeUnpushed = new ImageIcon("Selection Button Orange - Unpushed.png");
		ImageIcon buttonGreenUnpushed = new ImageIcon("Selection Button Green - Unpushed.png");
		ImageIcon buttonPurpleUnpushed = new ImageIcon("Selection Button Purple - Unpushed.png");
		
		//resize image icons
		buttonRedUnpushed = resizeButton(buttonRedUnpushed);
		buttonBlueUnpushed = resizeButton(buttonBlueUnpushed);
		buttonWhiteUnpushed = resizeButton(buttonWhiteUnpushed);
		buttonOrangeUnpushed = resizeButton(buttonOrangeUnpushed);
		buttonGreenUnpushed = resizeButton(buttonGreenUnpushed);
		buttonPurpleUnpushed = resizeButton(buttonPurpleUnpushed);
		
		//declare buttons
		button1 = new JLabel();
		button2 = new JLabel();
		button3 = new JLabel();
		button4 = new JLabel();
		button5 = new JLabel();
		button6 = new JLabel();
		
		//add icons
		button1.setIcon(buttonRedUnpushed);
		button2.setIcon(buttonBlueUnpushed);
		button3.setIcon(buttonWhiteUnpushed);
		button4.setIcon(buttonOrangeUnpushed);
		button5.setIcon(buttonGreenUnpushed);
		button6.setIcon(buttonPurpleUnpushed);
		
		//add mouse listeners
		button1.addMouseListener(new RedButtonListener());
		button2.addMouseListener(new BlueButtonListener());
		button3.addMouseListener(new WhiteButtonListener());
		button4.addMouseListener(new OrangeButtonListener());
		button5.addMouseListener(new GreenButtonListener());
		button6.addMouseListener(new PurpleButtonListener());
		
		
		//alignment
		button1.setHorizontalAlignment(SwingConstants.RIGHT);
		button2.setHorizontalAlignment(SwingConstants.LEFT);
		button3.setHorizontalAlignment(SwingConstants.RIGHT);
		button4.setHorizontalAlignment(SwingConstants.LEFT);
		button5.setHorizontalAlignment(SwingConstants.RIGHT);
		button6.setHorizontalAlignment(SwingConstants.LEFT);
		
		//add buttons to frame
		add(button1);
		add(button2);
		add(button3);
		add(button4);
		add(button5);
		add(button6);
		
	}

	/**
	 * This method resizes an ImageIcon to the appropriate height and width of the buttons
	 * @param i - the ImageIcon that needs resized
	 * @return - the ImageIcon that has been resized
	 */
	
	public static ImageIcon resizeButton(ImageIcon i)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(BUTTON_WIDTH, BUTTON_HEIGHT,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}
	
	/**
	 * This method resizes an image
	 * @param i - the ImageIcon that will be resized
	 * @param w - the width of the new ImageIcon
	 * @param h - the height of the new ImageIcon
	 * @return the resized ImageIcon
	 */
	
	public static ImageIcon resizeImage(ImageIcon i, int w, int h)
	{
		Image image = i.getImage();
		Image resizedImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		i = new ImageIcon(resizedImage);
		
		return i;
	}

	/**
	 * Listener for the red button
	 */
	private class RedButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonRedPushed = new ImageIcon("Selection Button Red - Pushed.png");
			buttonRedPushed = resizeButton(buttonRedPushed);
			button1.setIcon(buttonRedPushed);
			
		}

		public void mouseReleased(MouseEvent e) 
		{
			ImageIcon buttonRedUnpushed = new ImageIcon("Selection Button Red - Unpushed.png");
			buttonRedUnpushed = resizeButton(buttonRedUnpushed);
			button1.setIcon(buttonRedUnpushed);
			
			buttonRedUnpushed = resizeImage(buttonRedUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.level].buttons[index].setIcon(buttonRedUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'r';
			
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * Listener for the blue button
	 */
	private class BlueButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonBluePushed = new ImageIcon("Selection Button Blue - Pushed.png");
			buttonBluePushed = resizeButton(buttonBluePushed);
			button2.setIcon(buttonBluePushed);
		}

		public void mouseReleased(MouseEvent e) 
		{
			ImageIcon buttonBlueUnpushed = new ImageIcon("Selection Button Blue - Unpushed.png");
			buttonBlueUnpushed = resizeButton(buttonBlueUnpushed);
			button2.setIcon(buttonBlueUnpushed);
			
			buttonBlueUnpushed = resizeImage(buttonBlueUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.getLevel()].buttons[index].setIcon(buttonBlueUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'b';
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * Listener for the white button
	 */
	private class WhiteButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonWhitePushed = new ImageIcon("Selection Button White - Pushed.png");
			buttonWhitePushed = resizeButton(buttonWhitePushed);
			button3.setIcon(buttonWhitePushed);
		}

		public void mouseReleased(MouseEvent e) 
		{

			ImageIcon buttonWhiteUnpushed = new ImageIcon("Selection Button White - Unpushed.png");
			buttonWhiteUnpushed = resizeButton(buttonWhiteUnpushed);
			button3.setIcon(buttonWhiteUnpushed);
			
			buttonWhiteUnpushed = resizeImage(buttonWhiteUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.getLevel()].buttons[index].setIcon(buttonWhiteUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'w';
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * Listener for the orange button
	 */
	private class OrangeButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonOrangePushed = new ImageIcon("Selection Button Orange - Pushed.png");
			buttonOrangePushed = resizeButton(buttonOrangePushed);
			button4.setIcon(buttonOrangePushed);
		}

		public void mouseReleased(MouseEvent e) 
		{

			ImageIcon buttonOrangeUnpushed = new ImageIcon("Selection Button Orange - Unpushed.png");
			buttonOrangeUnpushed = resizeButton(buttonOrangeUnpushed);
			button4.setIcon(buttonOrangeUnpushed);
			
			buttonOrangeUnpushed = resizeImage(buttonOrangeUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.getLevel()].buttons[index].setIcon(buttonOrangeUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'o';
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * Listener for the green button
	 */
	private class GreenButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonGreenPushed = new ImageIcon("Selection Button Green - Pushed.png");
			buttonGreenPushed = resizeButton(buttonGreenPushed);
			button5.setIcon(buttonGreenPushed);
		}

		public void mouseReleased(MouseEvent e) 
		{

			ImageIcon buttonGreenUnpushed = new ImageIcon("Selection Button Green - Unpushed.png");
			buttonGreenUnpushed = resizeButton(buttonGreenUnpushed);
			button5.setIcon(buttonGreenUnpushed);
			
			buttonGreenUnpushed = resizeImage(buttonGreenUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.getLevel()].buttons[index].setIcon(buttonGreenUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'g';
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
	
	/**
	 * Listener for the purple button
	 */
	private class PurpleButtonListener implements MouseListener
	{
		public void mouseClicked (MouseEvent arg0) {}

		public void mousePressed(MouseEvent e) 
		{
			ImageIcon buttonPurplePushed = new ImageIcon("Selection Button Purple - Pushed.png");
			buttonPurplePushed = resizeButton(buttonPurplePushed);
			button6.setIcon(buttonPurplePushed);
		}

		public void mouseReleased(MouseEvent e) 
		{

			ImageIcon buttonPurpleUnpushed = new ImageIcon("Selection Button Purple - Unpushed.png");
			buttonPurpleUnpushed = resizeButton(buttonPurpleUnpushed);
			button6.setIcon(buttonPurpleUnpushed);
			
			buttonPurpleUnpushed = resizeImage(buttonPurpleUnpushed, 40, 40);
			cpContainer.choicePanels[cpContainer.getLevel()].buttons[index].setIcon(buttonPurpleUnpushed);
			cpContainer.choicePanels[cpContainer.level].buttonValues[index] = 'p';
		}

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

	}
}
